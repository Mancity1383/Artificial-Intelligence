"""
Gomoku AI Template
------------------
TODO Template for implementing different AI strategies:
    - Random Move
    - Monte Carlo (simple heuristic version)
    - Minimax
    - Alpha-Beta Pruning
"""

import sys
import math
import random

sys.setrecursionlimit(1500)
N = 15  # board size (15x15)


class GomokuAI:
    def __init__(self, depth=3):
        self.depth = depth
        self.boardMap = [[0 for _ in range(N)] for _ in range(N)]
        self.currentI = -1
        self.currentJ = -1
        self.boardValue = 0
        self.turn = 0
        self.lastPlayed = 0
        self.emptyCells = N * N
        self.nextBound = {}

    #######################################################
    # --- Basic utilities (already implemented) ---
    #######################################################
    def drawBoard(self):
        for i in range(N):
            for j in range(N):
                val = self.boardMap[i][j]
                print("x|" if val == 1 else "o|" if val == -1 else ".|", end=" ")
            print()
        print()

    def setState(self, i, j, state):
        assert state in (-1, 0, 1)
        self.boardMap[i][j] = state
        self.lastPlayed = state

    def childNodes(self, bound):
        for pos in sorted(bound.items(), key=lambda el: el[1], reverse=True):
            yield pos[0]

    def checkResult(self):
        if self.isFive(self.currentI, self.currentJ, self.lastPlayed):
            return self.lastPlayed
        elif self.emptyCells <= 0:
            return 0  # tie
        else:
            return None
        
    def getWinner(self):
        if self.checkResult() == 1:
            return "Black AI"
        if self.checkResult() == -1:
            return "White AI"
        return "None"

    def firstMove(self):
        """Place first stone in the center of the board."""
        self.currentI, self.currentJ = N // 2, N // 2
        self.setState(self.currentI, self.currentJ, 1)
        self.emptyCells -= 1
        if not self.nextBound:
            self.nextBound = {}
        self.updateBound(self.currentI, self.currentJ, self.nextBound)

    def updateBound(self, new_i, new_j, bound):
        bound.pop((new_i, new_j), None)
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                ni, nj = new_i + dx, new_j + dy
                if 0 <= ni < N and 0 <= nj < N and self.boardMap[ni][nj] == 0:
                    bound[(ni, nj)] = bound.get((ni, nj), 0) + 1

    def isValid(self, i, j):
        return 0 <= i < N and 0 <= j < N and self.boardMap[i][j] == 0

    def countDirection(self, i, j, xdir, ydir, state):
        count = 0
        x, y = i + xdir, j + ydir
        while 0 <= x < N and 0 <= y < N and self.boardMap[x][y] == state:
            count += 1
            x += xdir
            y += ydir
        return count

    def isFive(self, i, j, state):
        if i < 0 or j < 0:
            return False
        directions = [(1, 0), (0, 1), (1, 1), (1, -1)]
        for dx, dy in directions:
            total = 1 + self.countDirection(i, j, dx, dy, state) + self.countDirection(i, j, -dx, -dy, state)
            if total >= 5:
                return True
        return False

    def evaluate(self, new_i, new_j, board_value, turn, bound):
        """Basic heuristic evaluation for connected stones."""
        score = 0
        directions = [(1, 0), (0, 1), (1, 1), (1, -1)]
        for dx, dy in directions:
            count = 1 + self.countDirection(new_i, new_j, dx, dy, turn) + self.countDirection(new_i, new_j, -dx, -dy, turn)
            if count >= 5:
                score += 100000
            elif count == 4:
                score += 10000
            elif count == 3:
                score += 1000
            elif count == 2:
                score += 100
        bonus = bound.get((new_i, new_j), 0) if bound is not None else 0
        return board_value + score * (1 if turn == 1 else -1) + 0.1 * bonus

    #######################################################
    # --- TODO: Implement the following strategies ---
    #######################################################

    def randomMove(self):
        """
        TODO: Select a random valid move.
        Steps:
          - Collect all empty cells on the board.
          - Randomly choose one of them.
          - Update self.currentI, self.currentJ.
        """
        pass

    def monteCarloTreeSearch(self, board_value, bound):
        """
        TODO: Implement a simple Monte Carlo (heuristic) move selector.
        Hints:
          - Iterate over possible moves from 'bound'.
          - For each move:
              1. Temporarily place a stone.
              2. Evaluate it with self.evaluate().
              3. Undo the move.
          - Pick the move with the highest score.
        """
        pass

    def minimax(self, depth, board_value, bound, maximizingPlayer):
        """
        TODO: Implement the minimax algorithm (no alpha-beta pruning).
        Hints:
          - Use recursion with alternating maximizing/minimizing players.
          - Return (i, j) of the best move.
          - Base case: depth == 0 or terminal (checkResult != None).
        """
        pass

    def alphaBetaPruning(self, depth, board_value, bound, alpha, beta, maximizingPlayer):
        """
        TODO: Implement minimax with alpha-beta pruning.
        Hints:
          - Same structure as minimax but include alpha/beta checks.
          - Prune branches where beta <= alpha.
          - Keep track of the best move found at the top depth.
        """
        pass
